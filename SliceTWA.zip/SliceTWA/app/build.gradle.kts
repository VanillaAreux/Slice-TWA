plugins {
    id("com.android.application")
}

android {
    namespace = "com.jor.slice.twa"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jor.slice.twa"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sign with your own keystore before distributing — see README.md.
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Google's Trusted Web Activity helper — this is the same library Bubblewrap generates into
    // its projects. It gives us LauncherActivity for free: the whole app is config, no Kotlin/Java
    // UI code needed, it just launches Chrome in TWA mode pointed at HOST_URL below.
    implementation("com.google.androidbrowserhelper:androidbrowserhelper:2.6.1")

    // Pin androidx.browser to a stable release. Without this Gradle resolves it to
    // 1.9.0-alpha04, which needs compileSdk 36 / AGP 8.9.1 and breaks the build.
    implementation("androidx.browser:browser") {
        version { strictly("1.8.0") }
    }
}
