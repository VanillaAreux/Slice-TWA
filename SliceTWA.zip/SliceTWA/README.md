# Slice for Android (TWA)

A thin native wrapper around slicesocial.vercel.app using a Trusted Web Activity —
real app icon, splash screen, no browser URL bar, same push notifications your
site already sends. No changes needed on the server; this just points Chrome
at your existing site.

It uses `com.google.androidbrowserhelper`, the same library Google's own
Bubblewrap CLI generates — there's no app code to write, it's all config in
`AndroidManifest.xml` and the `res/values` files.

## Build it (sideload, no Play listing needed)

1. Open this folder in Android Studio (or `./gradlew assembleRelease` from the
   command line with the Android SDK installed).
2. `./generate_signing.sh` — creates `release.keystore` and prints your
   SHA256 fingerprint + the `assetlinks.json` you need to host.
3. Paste that fingerprint into
   `app/src/main/res/values/asset_statements.xml` (replace
   `REPLACE_WITH_YOUR_SHA256_FINGERPRINT`).
4. Copy the printed `assetlinks.json` to your web project at
   `public/.well-known/assetlinks.json` and redeploy. (Without this step the
   app still works — it just falls back to a normal Chrome Custom Tab with
   the URL bar visible instead of the chromeless "real app" look.)
5. Build the signed release APK:
   ```
   ./gradlew assembleRelease
   ```
   Output: `app/build/outputs/apk/release/app-release-unsigned.apk` — sign it
   with your keystore (Android Studio's Build > Generate Signed Bundle/APK
   wizard does this for you, or use `apksigner`).
6. Copy the signed APK to your phone and install it (enable "install unknown
   apps" for whichever app you transfer it with — Files, Drive, etc).

## If you ever do want a Play Store listing later

Nothing here needs to change — an AAB (`./gradlew bundleRelease`) built the
same way is exactly what Play Console wants. `store_icon/icon-512.png` is
already sized for the Play listing icon if that day comes.

## Changing things

- **Launch URL / app name**: `app/src/main/res/values/strings.xml`
- **Colors / splash**: `app/src/main/res/values/colors.xml` (currently
  pulled from your `manifest.webmanifest`'s `theme_color`/`background_color`
  — update both places together if you ever change Slice's theme colors)
- **Icon**: regenerate from `public/icon.svg` and drop into the
  `mipmap-*` folders (`ic_launcher.png` + `ic_launcher_round.png`)
