#!/bin/bash
# Run this once, from this folder, with a JDK installed (keytool ships with it).
# It creates a release keystore for the app and prints:
#   1. the SHA256 fingerprint to paste into asset_statements.xml
#   2. the exact assetlinks.json content to host on slicesocial.vercel.app
#
# KEEP release.keystore and the password safe — losing it means you can never
# ship an update to the same app under this applicationId again.

set -e
KEYSTORE=release.keystore
ALIAS=slice

if [ -f "$KEYSTORE" ]; then
  echo "release.keystore already exists — delete it first if you want a new one."
else
  keytool -genkeypair -v \
    -keystore "$KEYSTORE" \
    -alias "$ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10000
fi

echo
echo "=== SHA256 fingerprint (paste into app/src/main/res/values/asset_statements.xml) ==="
FINGERPRINT=$(keytool -list -v -keystore "$KEYSTORE" -alias "$ALIAS" | grep 'SHA256:' | sed 's/.*SHA256: //')
echo "$FINGERPRINT"

echo
echo "=== Host this at https://slicesocial.vercel.app/.well-known/assetlinks.json ==="
cat <<EOF
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.slicetechnologies.slice",
    "sha256_cert_fingerprints": ["$FINGERPRINT"]
  }
}]
EOF
